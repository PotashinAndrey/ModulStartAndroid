package com.example.potashin.data.model

data class Credentials (
    val email: String,
    val password: String
) {

}
