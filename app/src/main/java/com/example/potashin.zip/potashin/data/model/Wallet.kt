package com.example.potashin.data.model

import java.util.*

data class Wallet (
    val amount: Number,
    val id: UUID,
    val name: String,
    val number: String,
    val user: UUID
) {

}
